// Configuration (Google Apps Script Web App)
window.POINTAGE_CONFIG = {
  API_URL: "https://script.google.com/macros/s/AKfycbx4RJtQ53EBa2W2qd9MnT76pN-MHbCEhSm76boHxKBTr3th50q1KkhacDQHeMYcS4eR/exec",
  TOKEN: "TOKEN_OLM_FANZONE_2025_12H_18H",
  PDF_LOGO_PATH: "./assets/logo-slot.png"
};
